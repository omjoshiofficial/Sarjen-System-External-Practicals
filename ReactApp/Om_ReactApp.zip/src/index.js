import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Counter from './Counter';
import Countdown from './Countdown';
// import Degreemaster from './Degreemaster';
import RegistrationForm from './RegistrationForm';
import MiniCalculator from './MiniCalculator';
import CounterWithLocalStorage from './CounterWithLocalStorage';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import CounterFunc from './Functional/CounterFunc';
import Registration from './Functional/Registration';
import Login from './Functional/Login';
import Dashboard from './Functional/Dashboard';
import ToDoWithClass from './ToDoWithClass';
import ToDoWithFunc from './Functional/ToDoWithFunc';
import Crud from './Functional/Crud';
import Movies from './Functional/API_CALL/Movies';
import APICall1 from './Functional/API_CALL/APICall1';
import CrudApi from './Functional/API_CALL/CrudApi';
import APICall2 from './Functional/API_CALL/APICall2';
import APICall3 from './Functional/API_CALL/APICall3';
import APICall4 from './Functional/API_CALL/APICall4';
import APICall5 from './Functional/API_CALL/APICall5';
import APICall6 from './Functional/API_CALL/APICall6';
import APICall7 from './Functional/API_CALL/APICall7';
import DarkLightModePage from './Functional/DarkLightModePage';
import { DarkModeProvider } from './Functional/DarkModeContext';
// import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>

  {/* <Degreemaster/>     */}

  <Router>
    <Routes>
      <Route path='/' element={<App/>}/>
      <Route path='/counter' element={<Counter/>}/>
      <Route path='/Countdown' element={<Countdown/>}/>
      <Route path='/RegistrationForm' element={<RegistrationForm/>}/>
      <Route path='/MiniCalculator' element={<MiniCalculator/>}/>
      <Route path='/CounterWithLocalStorage' element={<CounterWithLocalStorage/>}/>
      <Route path='/todowithclass' element={<ToDoWithClass/>}/>
      
      <Route path='/CounterFunc' element={<CounterFunc/>}/>
      <Route path='/register' element={<Registration/>}/>
      <Route path='/login' element={<Login/>}/>
      <Route path='/dashboard' element={<Dashboard/>}/>
      <Route path='/todowithfunc' element={<ToDoWithFunc/>}/>
      <Route path='/crud' element={<Crud/>}/>
      <Route path='/movieapi' element={<Movies/>}/>
      <Route path='/api1' element={<APICall1/>}/>
      <Route path='/api2' element={<APICall2/>}/>
      <Route path='/api3' element={<APICall3/>}/>
      <Route path='/api4' element={<APICall4/>}/>
      <Route path='/api5' element={<APICall5/>}/>
      <Route path='/api6' element={<APICall6/>}/>
      <Route path='/api7' element={<APICall7/>}/>
      <Route path='/crudapi' element={<CrudApi/>}/>
      <Route path='/DarkLightPage' element={<DarkModeProvider><DarkLightModePage/></DarkModeProvider>}/>
    </Routes>
  </Router>

    </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();
