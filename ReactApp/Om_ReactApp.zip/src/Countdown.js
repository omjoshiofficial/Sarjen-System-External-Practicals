import React from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

class Countdown extends React.Component {
  constructor(props) {
    super(props);
    this.state = { count: 0 };
    this.intervalId = null;
  }

  startIncrement() {
    if (!this.intervalId) {
      this.intervalId = setInterval(() => {
        this.setState({ count: this.state.count + 1 });
      }, 1000);
    }
  }

  pauseInterval() {
    clearInterval(this.intervalId);
    this.intervalId = null;
  }

  stopInterval() {
    clearInterval(this.intervalId);
    this.setState({ count: 0 });
    this.intervalId = null;
  }

  render() {
    return (
      <div className="container mt-5 d-flex flex-column align-items-center">
        {/* Home Link */}
        <Link to="/" className="btn btn-secondary mb-3">
          Home
        </Link>

        {/* Countdown Card */}
        <div className="card text-center shadow-lg p-4" style={{ width: "300px" }}>
          <h2 className="text-primary">Countdown Timer</h2>
          
          {/* Count Display */}
          <h3 className="mt-3">
            Count: <span className="text-success fw-bold">{this.state.count}</span>
          </h3>

          {/* Buttons */}
          <div className="mt-3">
            <button
              className="btn btn-success me-2"
              onClick={this.startIncrement.bind(this)}
            >
              Start
            </button>

            <button
              className="btn btn-warning me-2"
              onClick={this.pauseInterval.bind(this)}
            >
              Pause
            </button>

            <button
              className="btn btn-danger"
              onClick={this.stopInterval.bind(this)}
            >
              Stop
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Countdown;
