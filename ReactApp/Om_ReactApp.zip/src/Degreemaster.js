import axios from "axios";
import { useEffect, useState } from "react";

const Degreemaster = () => {
    const [list, setList] = useState([]);

    useEffect(() => {
        axios.get('http://localhost/FFORCEWEB/MyDegreeMst/getDegreeMstData')
            .then(response => {
                try {
                    // Ensure `response.data.res` is parsed correctly
                    const parsedData = JSON.parse(response.data.res);
                    if (Array.isArray(parsedData)) {
                        setList(parsedData);
                    } else {
                        console.error("Parsed data is not an array:", parsedData);
                    }
                } catch (error) {
                    console.error("Error parsing JSON:", error);
                }
            })
            .catch(error => {
                console.error("API fetch error:", error);
            });
    }, []);

    return (
        <>
            <table border="1">
                <thead>
                    <tr>
                        <th>Degree No</th>
                        <th>Degree Name</th>
                    </tr>
                </thead>
                <tbody>
                    {list.map((data, index) => (
                        <tr key={index}>
                            <td>{data.DegreeNo}</td>
                            <td>{data.DegreeName}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    );
};

export default Degreemaster;
