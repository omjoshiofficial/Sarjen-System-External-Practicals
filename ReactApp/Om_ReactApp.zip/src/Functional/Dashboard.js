import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

function Dashboard(props) {
    const navigate = useNavigate();
    const [isChangepsw, setIsChangepsw] = useState(false);
    const [psw, setPsw] = useState({ oldpsw: "", newpsw: "" });

    const changepsw = () => {
        setIsChangepsw(true);
    };

    const updatepsw = () => {
        if (props.user.password === psw.oldpsw) {
            const newData = { ...props.user, password: psw.newpsw };
            localStorage.setItem("user", JSON.stringify(newData));
            alert("Password Updated! Please log in again.");
            navigate("/login");
            window.location.reload();
        } else {
            alert("Old password doesn't match.");
        }
    };

    return (
        <div className="container mt-5">
            {/* Dashboard Card */}
            <div className="card shadow-lg p-4 mx-auto" style={{ maxWidth: "500px" }}>
                <h2 className="text-center text-primary">Dashboard</h2>

                <div className="mb-3">
                    <strong>Name:</strong> {props.user.name}
                </div>
                <div className="mb-3">
                    <strong>Email:</strong> {props.user.email}
                </div>
                <div className="mb-3">
                    <strong>Age:</strong> {props.user.age}
                </div>
                <div className="mb-3">
                    <strong>City:</strong> {props.user.city}
                </div>

                {/* Change Password Button */}
                <button className="btn btn-warning w-100 mb-3" onClick={changepsw}>
                    Change Password
                </button>

                {/* Password Change Form */}
                {isChangepsw && (
                    <div className="border-top pt-3">
                        <div className="mb-3">
                            <label className="form-label">Old Password</label>
                            <input
                                type="password"
                                className="form-control"
                                placeholder="Enter old password..."
                                onChange={(e) => setPsw({ ...psw, oldpsw: e.target.value })}
                            />
                        </div>

                        <div className="mb-3">
                            <label className="form-label">New Password</label>
                            <input
                                type="password"
                                className="form-control"
                                placeholder="Enter new password..."
                                onChange={(e) => setPsw({ ...psw, newpsw: e.target.value })}
                            />
                        </div>

                        <button className="btn btn-success w-100" onClick={updatepsw}>
                            Update Password
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}

export default Dashboard;
