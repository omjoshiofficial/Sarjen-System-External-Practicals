import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

const Crud = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [DeletemodalOpen, setDeletemodalOpen] = useState(false);
  const [deleteId, setDeleteId] = useState(-1)
  const [userList, setUserList] = useState([])
  const [editmode, setEditMode] = useState(false)
  const [formData, setFormData] = useState({
    userid: '',
    name: '',
    gender: '',
    email: '',
    mobile: '',
    password: ''
  });
  const [errors, setErrors] = useState({});

  //ManageStates
  useEffect(() => {
    setUserList(JSON.parse(localStorage.getItem("CrudAppUsers")) || [])
  }, [])

  //OnChange Effect
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value })

    validateDataOnChange(name, value);

  }

  // Validate fields on change
  const validateDataOnChange = (name, value) => {
    let newErr = { ...errors };

    switch (name) {
      case "name":
        newErr.name = value.length < 2 ? "Name must be at least 2 characters" : "";
        break;
      case "email":
        newErr.email = !/\S+@\S+\.\S+/.test(value) ? "Enter a valid email" : "";
        break;
      case "mobile":
        newErr.mobile = value.length !== 10 ? "Mobile number must be 10 digits" : "";
        break;
      case "password":
        newErr.password = value.length < 8 ? "Password must be at least 8 characters" : "";
        break;
      case "gender":
        newErr.gender = value ? "" : "Gender is required";
        break;
      default:
        break;
    }

    setErrors(newErr);
  };

  // Validate all fields on submit
  const validateOnSubmit = () => {
    let newErr = {};

    if (formData.name.length < 2) newErr.name = "Name must be at least 2 characters";
    if (!/\S+@\S+\.\S+/.test(formData.email)) newErr.email = "Enter a valid email";
    if (formData.mobile.length !== 10) newErr.mobile = "Mobile number must be 10 digits";
    if (formData.password.length < 8) newErr.password = "Password must be at least 8 characters";
    if (!formData.gender) newErr.gender = "Gender is required";

    setErrors(newErr);

    return Object.keys(newErr).length === 0; // Returns true if no errors
  };

  const handleCloseModal = () => {
    setModalOpen(false)
    setFormData({
      userid: '',
      name: '',
      gender: '',
      email: '',
      mobile: '',
      password: ''
    })
  }

  //Handle Form Submission
  const handleSubmit = () => {

    if (validateOnSubmit()) {

      if (editmode) {
        const EditedData = userList.map((user) => (
          user.userid === formData.userid ? formData : user
        ))

        setUserList(EditedData);
        localStorage.setItem("CrudAppUsers", JSON.stringify(EditedData));

        setEditMode(false);

      } else {
        let highestId = userList.length > 0 ? Math.max(...userList.map(user => user.userid)) : 0
        alert("Form Submitted Successfully!");
        let UserData = {
          ...formData,
          userid: highestId + 1
        }
        let updatedCrudAppUsers = userList;
        updatedCrudAppUsers.push(UserData);
        localStorage.setItem("CrudAppUsers", [JSON.stringify(updatedCrudAppUsers)]);

      }

      setModalOpen(false);

      setFormData({ name: "", gender: "", email: "", mobile: "", password: "" });
      setErrors({});
    }
  }

  //handle click of edit button
  const handleEditClick = (val) => {
    setModalOpen(true)
    setFormData(val)
    setEditMode(true)
  }

  //handle click of delete button
  const handleDelete = (id) => {
    setDeletemodalOpen(true)
    setDeleteId(id)

  }

  //handle yes of Delete Modal popup
  const handleYes = () => {
    const updatedUserList = userList.filter(user => user.userid !== deleteId)
    setUserList(updatedUserList)
    if (updatedUserList.length % userPerPage === 0 && currentPage > 1) {
      setCurrentPage(currentPage - 1)
    }

    localStorage.setItem("CrudAppUsers", JSON.stringify(updatedUserList))

    setDeletemodalOpen(false)
    setDeleteId(-1)
  }

  //Pagination
  const [currentPage, setCurrentPage] = useState(1)
  const userPerPage = 2

  // Get current products based on pagination
  const indexOfLastUser = currentPage * userPerPage;
  const indexOfFirstUser = indexOfLastUser - userPerPage;
  const currentUserList = userList.slice(indexOfFirstUser, indexOfLastUser);

  return (
    <div className="container mt-5">

      <div className="mb-3">
        <Link to="/" className="btn btn-secondary">Home</Link>
      </div>

      <h2 className="text-center mb-4">CRUD Operations</h2>

      {/* Add Button */}
      <div className="d-flex justify-content-end mb-3">
        <button className="btn btn-primary" onClick={() => setModalOpen(true)}>
          Add New Item
        </button>
      </div>

      {/* Table */}
      <table className="table table-bordered">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {
            currentUserList.length > 0 ? (
              currentUserList.map((val, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{val.name}</td>
                  <td>{val.gender}</td>
                  <td>{val.email}</td>
                  <td>{val.mobile}</td>
                  <td>
                    <button className="btn btn-warning btn-sm me-2" onClick={() => handleEditClick(val)}>Edit</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(val.userid)}>Delete</button>
                  </td>
                </tr>
              ))) : (<tr>
                <td colSpan="6"><center><b>No Records Found</b></center></td>
              </tr>)
          }

        </tbody>
      </table>

      {/* Pagination Controls */}
      <nav>
        <ul className="pagination justify-content-center">
          {
            Array.from({ length: Math.ceil(userList.length / userPerPage) }, (_, i) => (
              <li key={i} className={`page-item ${currentPage === i + 1 ? "active" : ""}`}>
                <button onClick={() => setCurrentPage(i + 1)} className="page-link">
                  {i + 1}
                </button>
              </li>
            ))

          }
        </ul>
      </nav>

      {/* Modal for Add/Edit */}
      {modalOpen && (
        <div className="modal d-block bg-dark bg-opacity-50" tabIndex="-1">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{editmode ? "Edit" : "Add"} Item</h5>
                <button className="btn-close" onClick={handleCloseModal}></button>
              </div>
              <div className="modal-body">
                <form>
                  <div className="mb-3">
                    <label className="form-label">Name</label>
                    <input type="text" name="name" value={formData.name} className="form-control" onChange={(e) => handleChange(e)} />
                    {errors.name && <small className="text-danger">{errors.name}</small>}
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Gender</label> <br />
                    <input type="radio" name="gender" radioGroup="gen" value="Male" checked={formData.gender === 'Male'} onChange={(e) => handleChange(e)} /> Male {" "}
                    <input type="radio" name="gender" radioGroup="gen" value="Female" checked={formData.gender === 'Female'} onChange={(e) => handleChange(e)} /> Female
                    <br />
                    {errors.gender && <small className="text-danger">{errors.gender}</small>}
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input type="email" name="email" className="form-control" value={formData.email} onChange={(e) => handleChange(e)} />
                    {errors.email && <small className="text-danger">{errors.email}</small>}

                  </div>
                  <div className="mb-3">
                    <label className="form-label">Mobile</label>
                    <input type="number" name="mobile" className="form-control" value={formData.mobile} onChange={(e) => handleChange(e)} />
                    {errors.mobile && <small className="text-danger">{errors.mobile}</small>}
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input type="password" name="password" className="form-control" value={formData.password} onChange={(e) => handleChange(e)} />
                    {errors.password && <small className="text-danger">{errors.password}</small>}
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={handleCloseModal}>Close</button>
                <button className="btn btn-success" onClick={handleSubmit}>{editmode ? 'Update' : 'Save'}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal for Delete */}
      {DeletemodalOpen && (
        <div className="modal d-block bg-dark bg-opacity-50" tabIndex="-1">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Delete</h5>
                <button className="btn-close" onClick={() => setDeletemodalOpen(false)}></button>
              </div>
              <div className="modal-body m-auto">
                <input type="hidden" value={deleteId} />
                <h4>Are You Sure To Delete Record?</h4>
              </div>
              <div className="modal-body m-auto">
                <button className="btn btn-danger" onClick={() => setDeletemodalOpen(false)}>No</button>
                <button className="btn btn-success ms-3" onClick={handleYes}>Yes</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Crud;
