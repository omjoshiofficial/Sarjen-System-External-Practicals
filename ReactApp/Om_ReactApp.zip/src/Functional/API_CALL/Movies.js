import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Movies = () => {

    const [moviesList, setMoviesList] = useState([]);

    useEffect(() => {

        axios.get("https://www.freetestapi.com/api/v1/movies")
            .then(res => setMoviesList(res.data))

    }, []);


    return <>
        <div className="container mt-5">
            <div className="mb-3">
                <Link to="/" className="btn btn-secondary">Home</Link>
            </div>

            <div className="card shadow-sm bg-body-tertiary p-4">

                <div className="row">

                    {
                        moviesList.map((value, index) => (
                            <div className="col-md-4" key={value.id}>
                                <div className="card-body bg-body shadow-sm mb-3">
                                    <h5 className="card-title">{value.title}</h5>
                                    <p className="card-text"><strong>Genre:</strong> {
                                        value.genre.length > 1 ? (
                                            value.genre.map((v, i) => (<small key={i}>{v}, </small>))
                                        ) : (value.genre)
                                    }</p>
                                    <p className="card-text"><strong>Director:</strong> {value.director}</p>
                                    <p className="card-text"><strong>Actors:</strong> {
                                        value.actors.length > 1 ? (
                                            value.actors.map((v, i) => (<small key={i}>{v}, </small>))
                                        ) : (value.actors)
                                    }</p>
                                    <p className="card-text"><strong>Plot:</strong>{value.plot}</p>
                                    <p className="card-text"><strong>Rating:</strong> ⭐ {value.rating}</p>
                                    <p className="card-text"><strong>Runtime:</strong> {value.runtime} minutes</p>
                                    <p className="card-text"><strong>Awards:</strong> {value.awards}</p>
                                    <p className="card-text"><strong>Box Office:</strong> {value.boxOffice}</p>
                                    <p className="card-text"><strong>Production:</strong> {value.production}</p>
                                    <p className="card-text"><strong>Country:</strong> {value.country} | <strong>Language:</strong> {value.language}</p>
                                    <div className="d-flex">
                                        <a href="http://www.warnerbros.com/movies/shawshank-redemption" className="btn btn-primary me-2">Official Site</a>
                                        <a href="https://example.com/shawshank_redemption_trailer.mp4" className="btn btn-danger" >Watch Trailer</a>
                                    </div>
                                </div>
                            </div>
                        ))
                    }

                </div>

            </div>

        </div>
    </>
}

export default Movies;