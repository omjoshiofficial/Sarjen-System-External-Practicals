import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const APICall2 = () => {

    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        axios.get("https://api.escuelajs.co/api/v1/products")
            .then((res) => {
                setProducts(res.data);
                setLoading(false);
            })
            .catch((err) => {
                console.error("API Fetch Error:", err);
                setError("Failed to fetch data. Please try again.");
                setLoading(false);
            });
    }, []);

    return (
        <div className="container mt-5">
            {/* Home Button */}
            <div className="mb-3">
                <Link to="/" className="btn btn-secondary">
                    Home
                </Link>
            </div>

            {/* Loading & Error Handling */}
            {loading && <h3 className="text-center">Loading...</h3>}
            {error && <h4 className="text-danger text-center">{error}</h4>}

            {!loading && !error && (
                <div className="table-responsive">
                    <table className="table table-striped table-hover border">
                        <thead className="table-dark">
                            <tr>
                                <th>#</th>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Slug</th>
                                <th>Price</th>
                                <th>Description</th>
                                <th>Category</th>
                                <th>Images</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                        <tbody>
                            {products.map((product, index) => (
                                <tr key={product.id}>
                                    <th scope="row">{index + 1}</th>
                                    <td>{product.id}</td>
                                    <td>{product.title}</td>
                                    <td>{product.slug}</td>
                                    <td>${product.price}</td>
                                    <td className="text-truncate" style={{ maxWidth: "200px" }}>
                                        {product.description}
                                    </td>
                                    <td>
                                        <div className="border p-2">
                                            <strong>Name:</strong> {product.category.name} <br />
                                            <strong>Slug:</strong> {product.category.slug} <br />
                                            <img
                                                src={product.category.image}
                                                alt="Category"
                                                className="img-fluid"
                                                width="50"
                                            />
                                        </div>
                                    </td>
                                    <td>
                                        {product.images.map((img, i) => (
                                            <img
                                                key={i}
                                                src={img}
                                                alt="Product"
                                                className="img-thumbnail mx-1"
                                                width="50"
                                            />
                                        ))}
                                    </td>
                                    <td>{new Date(product.creationAt).toLocaleDateString()}</td>
                                    <td>{new Date(product.updatedAt).toLocaleDateString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );

}

export default APICall2;