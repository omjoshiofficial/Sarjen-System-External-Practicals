import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

function Registration() {
    const navigate = useNavigate();
    const [user, setUser] = useState({ name: '', email: '', password: '', age: '', city: '' });
    const [errors, setErrors] = useState({});

    const setUserData = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const saveData = () => {
        let newErrors = {};

        if (!user.name || user.name.length < 2) {
            newErrors.name = "Name is required and must be > 2 characters";
        }

        if (!user.email) {
            newErrors.email = "Email is required";
        }

        if (!user.password || user.password.length < 8) {
            newErrors.password = "Password is required and must be > 8 characters";
        }

        if (!user.age || parseInt(user.age) <= 0) {
            newErrors.age = "Age is required and must be > 0";
        }

        if (!user.city || user.city.length < 3) {
            newErrors.city = "City is required and must be > 3 characters";
        }

        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
        } else {
            localStorage.setItem("user", JSON.stringify(user));
            alert("Registration Successful!");
            navigate('/login');
        }
    };

    return (
        <div className="container mt-5">
            {/* Navigation Links */}
            <div className="mb-3">
                <Link to="/" className="btn btn-secondary me-2">Home</Link>
                <Link to="/login" className="btn btn-primary">Login</Link>
            </div>

            {/* Registration Card */}
            <div className="card shadow-lg p-4 mx-auto" style={{ maxWidth: "500px" }}>
                <h2 className="text-center text-primary">Registration</h2>

                <div className="mb-3">
                    <label className="form-label">Name</label>
                    <input type="text" className="form-control" name="name" placeholder="Enter name..." onChange={setUserData} />
                    {errors.name && <div className="text-danger">{errors.name}</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input type="email" className="form-control" name="email" placeholder="Enter email..." onChange={setUserData} />
                    {errors.email && <div className="text-danger">{errors.email}</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input type="password" className="form-control" name="password" placeholder="Enter password..." onChange={setUserData} />
                    {errors.password && <div className="text-danger">{errors.password}</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Age</label>
                    <input type="number" className="form-control" name="age" placeholder="Enter age..." onChange={setUserData} />
                    {errors.age && <div className="text-danger">{errors.age}</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">City</label>
                    <input type="text" className="form-control" name="city" placeholder="Enter city..." onChange={setUserData} />
                    {errors.city && <div className="text-danger">{errors.city}</div>}
                </div>

                <button className="btn btn-success w-100" onClick={saveData}>Save</button>
            </div>
        </div>
    );
}

export default Registration;
