import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

function ToDoWithFunc() {
    const [arr, setArr] = useState([]);
    const [val, setVal] = useState("");
    const [editIndex, setEditIndex] = useState(null);

    useEffect(() => {
        const tasksList = JSON.parse(localStorage.getItem("tasks")) || [];
        setArr(tasksList);
    }, []);

    const handleSubmit = () => {
        let updatedArr = [...arr];

        if (editIndex !== null) {
            updatedArr[editIndex] = val;
            setEditIndex(null);
        } else {
            if (val.trim()) {
                updatedArr.push(val);
            }
        }

        setArr(updatedArr);
        localStorage.setItem("tasks", JSON.stringify(updatedArr));
        setVal('');
    };

    const handleEdit = (index) => {
        setEditIndex(index);
        setVal(arr[index]);
    };

    const handleDelete = (index) => {
        const updatedArr = arr.filter((_, i) => i !== index);
        setArr(updatedArr);
        localStorage.setItem("tasks", JSON.stringify(updatedArr));
    };

    return (
        <div className="container mt-5">
            {/* Navigation */}
            <div className="mb-3">
                <Link to="/" className="btn btn-secondary">Home</Link>
            </div>

            {/* To-Do List Card */}
            <div className="card shadow-lg p-4">
                <h2 className="text-center text-primary">To-Do List</h2>

                {/* Input Section */}
                <div className="input-group mb-3">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Enter task..."
                        value={val}
                        onChange={(e) => setVal(e.target.value)}
                    />
                    <button
                        className={` ms-2 btn ${editIndex !== null ? "btn-warning" : "btn-success"}`}
                        onClick={handleSubmit}
                    >
                        {editIndex !== null ? "Update Task" : "Add Task"}
                    </button>
                </div>

                {/* Task List */}
                <ul className="list-group">
                    {arr.length > 0 ? (
                        arr.map((value, index) => (
                            <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
                                <span>{value}</span>
                                <div>
                                    <button className="btn btn-info btn-sm me-2" onClick={() => handleEdit(index)}>
                                        Edit
                                    </button>
                                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(index)}>
                                        Delete
                                    </button>
                                </div>
                            </li>
                        ))
                    ) : (
                        <li className="list-group-item text-center text-muted">No Tasks Available</li>
                    )}
                </ul>
            </div>
        </div>
    );
}

export default ToDoWithFunc;
