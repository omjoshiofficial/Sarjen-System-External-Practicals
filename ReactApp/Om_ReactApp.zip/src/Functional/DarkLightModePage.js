import { useContext } from "react";
import { DarkModeContext } from "./DarkModeContext";
import { Link } from "react-router-dom";

const DarkLightModePage = () => {

    const { darkmode, toggleTheme } = useContext(DarkModeContext);

    return <>
        <div className="container mt-5">
            <div className="mb-3">
                <Link to="/" className="btn btn-secondary">Home</Link>
            </div>

        </div>

        <div className={`container p-5 mt-5 text-center rounded border border-1 ${darkmode ? 'bg-dark' : 'bg-light'}`}>

            <h1 className={`${darkmode ? 'text-light' : 'text-dark'}`}>{darkmode ? "Dark Mode 🌙" : "Light Mode ☀️"}</h1>
            <button className="mt-3 mb-1 rounded" onClick={toggleTheme}>Toggle Theme</button>
        </div>
    </>

}

export default DarkLightModePage;