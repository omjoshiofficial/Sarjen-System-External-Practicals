import { useState } from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

function CounterFunc() {
  const [counter, setCounter] = useState(0);

  return (
    <div className="container mt-5 d-flex flex-column align-items-center">
      {/* Home Link */}
      <Link to="/" className="btn btn-secondary mb-3">
        Home
      </Link>

      {/* Counter Card */}
      <div className="card text-center shadow-lg p-4" style={{ width: "300px" }}>
        <h2 className="text-primary">Counter</h2>
        
        {/* Count Display */}
        <h3 className="mt-3">
          Count: <span className="text-success fw-bold">{counter}</span>
        </h3>

        {/* Message Display */}
        {counter >= 5 ? (
          <p className="text-danger fw-bold">You reached 5</p>
        ) : counter <= 0 ? (
          <p className="text-danger fw-bold">You reached 0</p>
        ) : null}

        {/* Buttons */}
        <div className="mt-3">
          <button
            className="btn btn-success me-2"
            disabled={counter >= 5}
            onClick={() => setCounter(counter + 1)}
          >
            +
          </button>

          <button
            className="btn btn-danger"
            disabled={counter <= 0}
            onClick={() => setCounter(counter - 1)}
          >
            -
          </button>
        </div>
      </div>
    </div>
  );
}

export default CounterFunc;
