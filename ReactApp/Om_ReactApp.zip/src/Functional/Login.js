import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Dashboard from "./Dashboard";
import "bootstrap/dist/css/bootstrap.min.css";

function Login() {
    const [currentUser, setCurrentUser] = useState({ email: '', password: '' });
    const [userData, setUserData] = useState({});
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        const user = JSON.parse(localStorage.getItem("user"));
        if (user) {
            setUserData(user);
        }
    }, []);

    const loginUser = () => {
        if (currentUser.email === userData.email && currentUser.password === userData.password) {
            setIsLoggedIn(true);
            alert("Logged in successfully!");
        } else {
            alert("Invalid credentials. Please try again.");
        }
    };

    const forgetPsw = () => {
        if (currentUser.email === userData.email) {
            alert("Your Password is: " + userData.password);
        } else {
            alert("Please enter a valid email.");
        }
    };

    return (
        <div className="container mt-5">
            {/* Navigation Links */}
            <div className="mb-3">
                <Link to="/" className="btn btn-secondary me-2">Home</Link>
                <Link to="/register" className="btn btn-primary">Register</Link>
            </div>

            {/* Check if Logged In */}
            {isLoggedIn ? (
                <Dashboard user={userData} />
            ) : (
                <div className="card shadow-lg p-4 mx-auto" style={{ maxWidth: "400px" }}>
                    <h2 className="text-center text-primary">Login</h2>

                    <div className="mb-3">
                        <label className="form-label">Email</label>
                        <input 
                            type="email" 
                            className="form-control" 
                            placeholder="Enter email..." 
                            onChange={(e) => setCurrentUser({ ...currentUser, email: e.target.value })}
                        />
                    </div>

                    <div className="mb-3">
                        <label className="form-label">Password</label>
                        <input 
                            type="password" 
                            className="form-control" 
                            placeholder="Enter password..." 
                            onChange={(e) => setCurrentUser({ ...currentUser, password: e.target.value })}
                        />
                    </div>

                    <button className="btn btn-success w-100" onClick={loginUser}>Login</button>

                    <p className="text-center mt-2">
                        <button className="btn btn-link text-primary" onClick={forgetPsw}>Forgot Password?</button>
                    </p>
                </div>
            )}
        </div>
    );
}

export default Login;
