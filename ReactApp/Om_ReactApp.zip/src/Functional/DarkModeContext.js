import { createContext, useState } from "react";

export const DarkModeContext = createContext();

export const DarkModeProvider = ({children}) => {

    const [darkmode,setDarkMode] = useState(false);

    const toggleTheme = () => setDarkMode(!darkmode);

    return (
        <DarkModeContext.Provider value={{darkmode,toggleTheme}}>
            {children}
        </DarkModeContext.Provider>
    )
};

