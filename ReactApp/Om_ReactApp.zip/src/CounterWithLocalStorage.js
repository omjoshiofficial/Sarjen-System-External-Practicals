import React from "react";
import { Link } from "react-router-dom";

class CounterWithLocalStorage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            counter: parseInt(localStorage.getItem("counter")) || 0
        };
    }

    counterChange(e) {
        const op = e.target.value;

        switch (op) {
            case "+":
                this.setState({ counter: ++this.state.counter });
                break;
            case "-":
                this.setState({ counter: --this.state.counter });
                break;
            case "x":
                this.setState({ counter: 0 });
                break;
            default:
                break;
        }
        localStorage.setItem("counter", this.state.counter);
    }

    render() {
        return (

            <>
            <div className="App">
  
  <Link to='/' className="btn btn-secondary mt-3">Home</Link>
 

</div>

            <div style={styles.container}>
                <h2 style={styles.counterText}>Counter: {this.state.counter}</h2>
                <div style={styles.buttonContainer}>
                    <input 
                        type="button" 
                        value="+" 
                        disabled={this.state.counter >= 5} 
                        onClick={this.counterChange.bind(this)} 
                        style={this.state.counter >= 5 ? { ...styles.button, ...styles.disabledButton } : { ...styles.button, ...styles.plusButton }}
                    />
                    <input 
                        type="button" 
                        value="-" 
                        disabled={this.state.counter <= 0} 
                        onClick={this.counterChange.bind(this)} 
                        style={this.state.counter <= 0 ? { ...styles.button, ...styles.disabledButton } : { ...styles.button, ...styles.minusButton }}
                    />
                    <input 
                        type="button" 
                        value="x" 
                        onClick={this.counterChange.bind(this)} 
                        style={{ ...styles.button, ...styles.resetButton }}
                    />
                </div>
            </div>
            </>

        );
    }
}

const styles = {
    container: {
        textAlign: "center",
        fontFamily: "Arial, sans-serif",
        marginTop: "50px"
    },
    counterText: {
        fontSize: "24px",
        marginBottom: "20px",
        color: "#333"
    },
    buttonContainer: {
        display: "flex",
        justifyContent: "center",
        gap: "10px"
    },
    button: {
        fontSize: "18px",
        padding: "10px 15px",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
        transition: "0.3s",
        color: "white",
    },
    plusButton: {
        backgroundColor: "#4CAF50",
    },
    minusButton: {
        backgroundColor: "#FF5733",
    },
    resetButton: {
        backgroundColor: "#3498DB",
    },
    disabledButton: {
        backgroundColor: "#ccc",
        cursor: "not-allowed",
        color: "#666"
    }
};

export default CounterWithLocalStorage;
