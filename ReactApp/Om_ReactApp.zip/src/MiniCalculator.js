import React from "react";
import "./RegistrationForm.css";
import { Link } from "react-router-dom";

class MiniCalculator extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            ans:0
        };
    }

    setValues(e) {
        this.setState({[e.target.name]:e.target.value})
    }

    calculation(e) {
        const {no1,no2} = this.state

        const op = e.target.value
        var answer = 0

        switch (op) {
            case "+":
                answer = parseFloat(no1) + parseFloat(no2)
                break;
            case "-":
                answer = parseFloat(no1) - parseFloat(no2)
                break;
            case "*":
                answer = parseFloat(no1) * parseFloat(no2)
                break;
            case "/":
                answer = parseFloat(no1) / parseFloat(no2)
                break;
            default:
                break;
        }

        this.setState({ans:answer})
    }

    render() {
        return (
            <>
            
            <div className="App">
  
        <Link to='/' className="btn btn-secondary mt-3">Home</Link>

    </div>


            <div className="calculator-container">
                <h2>Mini Calculator</h2>

                <div className="input-group">
                    <label>No1:</label>
                    <input type="number" name="no1" onChange={this.setValues.bind(this)} />
                </div>

                <div className="input-group">
                    <label>No2:</label>
                    <input type="number" name="no2" onChange={this.setValues.bind(this)} />
                </div>

                <div className="button-group">
                    <input type="button" name="+" value="+" onClick={this.calculation.bind(this)} />
                    <input type="button" name="-" value="-" onClick={this.calculation.bind(this)} />
                    <input type="button" name="*" value="*" onClick={this.calculation.bind(this)} />
                    <input type="button" name="/" value="/" onClick={this.calculation.bind(this)} />
                </div>
                <br/> 
                <b>Ans =  {this.state.ans}</b>
            </div>

            </>

        );
    }
}

export default MiniCalculator;
