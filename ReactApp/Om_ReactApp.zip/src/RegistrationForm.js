import React from "react";
import "./RegistrationForm.css"; // Import CSS file
import { Link } from "react-router-dom";

class RegistrationForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        hobbies: {}
    };
  }

  fillAllData(e){

        if (e.target.type === "checkbox") {
            
            if (e.currentTarget.checked) {
                this.setState({hobbies:{...this.state.hobbies,[e.target.name]:e.target.value}})
            }
            else{
                delete this.state.hobbies[e.target.name]
                return this.state
            }

        }
        this.setState({[e.target.name]:e.target.value})
        
  }

  render() {

    return (
      <>

<div className="App">
  
  <Link to='/' className="btn btn-secondary mt-3">Home</Link>
  
</div>

      <div style={{display:"flex",justifyContent:'space-between'}}>

        <div className="form-container">
          <h2>Registration Form</h2>
          
            <div className="form-group">
              <label>Name</label>
              <input type="text" name="nametxt" placeholder="Enter your name" onChange={this.fillAllData.bind(this)} />
            </div>

            <div className="form-group">
              <label>Surname</label>
              <input type="text" name="sirnametxt" placeholder="Enter your surname" onChange={this.fillAllData.bind(this)} />
            </div>

            <div className="form-group">
              <label>Mobile</label>
              <input type="text" name="mobiletxt" placeholder="Enter your mobile number" onChange={this.fillAllData.bind(this)} />
            </div>

            <div className="form-group">
              <label>Email</label>
              <input type="email" name="emailtxt" placeholder="Enter your email" onChange={this.fillAllData.bind(this)} />
            </div>

            <div className="form-group">
              <label>Password</label>
              <input type="password" name="passwordtxt" placeholder="Enter your password" onChange={this.fillAllData.bind(this)} />
            </div>

            <div className="form-group">
                <label>City</label>
                <select name="city" onChange={this.fillAllData.bind(this)}>
                    <option>Ahm</option>
                    <option>Hmt</option>
                    <option>Idar</option>

                </select>
            </div>

            <div className="form-group">
              <label>Gender</label>
              <div className="radio-group">
                <label><input type="radio" name="gentxt" value="Male" onChange={this.fillAllData.bind(this)} /> Male</label>
                <label><input type="radio" name="gentxt" value="Female" onChange={this.fillAllData.bind(this)} /> Female</label>
              </div>
            </div>

            <div className="form-group">
              <label>Hobby</label>
              <div className="checkbox-group">
                <label><input type="checkbox" name="hobby1" value="coding" onChange={this.fillAllData.bind(this)} /> Coding</label>
                <label><input type="checkbox" name="hobby2" value="music" onChange={this.fillAllData.bind(this)} /> Music</label>
                <label><input type="checkbox" name="hobby3" value="learning" onChange={this.fillAllData.bind(this)} /> Learning</label>
              </div>
            </div>

            {/* <button type="button" className="submit-btn">Save</button> */}
          

        </div>
        <div className="form-container">
          <h2>Show Data</h2>
          
            <div className="form-group">
              <label>Name</label>
              <input type="text" name="nametxt" value={this.state.nametxt} readOnly />
            </div>

            <div className="form-group">
              <label>Surname</label>
              <input type="text" name="sirnametxt" value={this.state.sirnametxt} readOnly />
            </div>

            <div className="form-group">
              <label>Mobile</label>
              <input type="text" name="mobiletxt" value={this.state.mobiletxt} readOnly/>
            </div>

            <div className="form-group">
              <label>Email</label>
              <input type="email" name="emailtxt" value={this.state.emailtxt} readOnly/>
            </div>

            <div className="form-group">
              <label>Password</label>
              <input type="password" name="passwordtxt" value={this.state.passwordtxt} readOnly/>
            </div>

            <div className="form-group">
                <label>City</label>
                <select name="city" value={this.state.city} disabled>
                    <option>Ahm</option>
                    <option>Hmt</option>
                    <option>Idar</option>

                </select>
            </div>


            <div className="form-group">
              <label>Gender</label>
              <div className="radio-group">
                <label><input type="radio" name="gentxt" value="Male" checked={this.state.gentxt==='Male'} readOnly/> Male</label>
                <label><input type="radio" name="gentxt" value="Female" checked={this.state.gentxt==='Female'} readOnly/> Female</label>
              </div>
            </div>

            <div className="form-group">
              <label>Hobby</label>
              <div className="checkbox-group">
                <label><input type="checkbox" name="hobby1" value="coding" checked={!!this.state.hobbies.hobby1} readOnly /> Coding</label>
                <label><input type="checkbox" name="hobby2" value="music" checked={!!this.state.hobbies.hobby2} readOnly /> Music</label>
                <label><input type="checkbox" name="hobby3" value="learning" checked={!!this.state.hobbies.hobby3} readOnly /> Learning</label>
              </div>
            </div>

            {/* <button type="button" className="submit-btn">Save</button> */}

        </div>
      </div>

      </>
    );
  }
}

export default RegistrationForm;
