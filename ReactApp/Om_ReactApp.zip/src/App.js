import logo from "./logo.svg";
import "./App.css";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { useContext } from "react";
import { DarkModeContext } from "./Functional/DarkModeContext";

function App() {
  const bgcolor = useContext(DarkModeContext)
  return (
    <div className={`App ${bgcolor}`} >
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <div className="container">
          <a className="navbar-brand" href="/">
            <img src={logo} alt="Logo" width="40" height="40" />
            Om Joshi React App
          </a>
        </div>
      </nav>

      <div className="container mt-4">
        {/* Class Components Section */}
        <div className="row">
          <div className="col-md-6">
            <h2 className="text-primary">Class Components</h2>
            <ul className="list-group mb-4">
              <li className="list-group-item">
                <Link to="/" className="btn btn-link">Home</Link>
              </li>
              <li className="list-group-item">
                <Link to="/counter" className="btn btn-link">Counter</Link>
              </li>
              <li className="list-group-item">
                <Link to="/Countdown" className="btn btn-link">Countdown</Link>
              </li>
              <li className="list-group-item">
                <Link to="/RegistrationForm" className="btn btn-link">Registration Form</Link>
              </li>
              <li className="list-group-item">
                <Link to="/MiniCalculator" className="btn btn-link">Mini Calculator</Link>
              </li>
              <li className="list-group-item">
                <Link to="/CounterWithLocalStorage" className="btn btn-link">Counter With Local Storage</Link>
              </li>
              <li className="list-group-item">
                <Link to="/todowithclass" className="btn btn-link">To-Do With Class</Link>
              </li>
            </ul>
          </div>

          {/* Function Components Section */}
          <div className="col-md-6">
            <h2 className="text-success">Function Components</h2>
            <ul className="list-group mb-4">
              <li className="list-group-item">
                <Link to="/CounterFunc" className="btn btn-link">Counter Function</Link>
              </li>
              <li className="list-group-item">
                <Link to="/register" className="btn btn-link">Registration</Link>
              </li>
              <li className="list-group-item">
                <Link to="/todowithfunc" className="btn btn-link">To-Do With Function</Link>
              </li>
              <li className="list-group-item">
                <Link to="/crud" className="btn btn-link">CRUD</Link>
              </li>
              <li className="list-group-item">
                <h2 className="text-primary-emphasis">API Call</h2>
              </li>
              <li className="list-group-item">
                <Link to="/movieapi" className="btn btn-link">Movies</Link>
              </li>
              <li className="list-group-item">
                <Link to="/api1" className="btn btn-link">API 1</Link> |
                <Link to="/api2" className="btn btn-link">API 2</Link> |
                <Link to="/api3" className="btn btn-link">API 3</Link> |
                <Link to="/api4" className="btn btn-link">API 4</Link> |
                <Link to="/api5" className="btn btn-link">API 5</Link> |
                <Link to="/api6" className="btn btn-link">API 6</Link> |
                <Link to="/api7" className="btn btn-link">API 7</Link>
              </li>
              
              <li className="list-group-item">
                <Link to="/crudapi" className="btn btn-link">Crud</Link>
              </li>
              <li className="list-group-item">
                <h2 className="text-primary-emphasis">Context Api</h2>
              </li>
              <li className="list-group-item">
                <Link to="/DarkLightPage" className="btn btn-link">DarkLightPage</Link>
              </li>

            </ul>
          </div>
        </div>

        {/* HomePage Section */}
        <div className="text-center mt-4">
          <h2 className="text-secondary">HomePage</h2>
        </div>
      </div>
    </div>
  );
}

export default App;
