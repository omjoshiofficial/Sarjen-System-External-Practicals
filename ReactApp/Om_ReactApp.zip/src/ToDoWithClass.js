import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

class ToDoWithClass extends React.Component {
  constructor(props) {
    super();
    this.state = {
      arr: [],
      txtvalue: "",
      editIndex: null,
    };
  }

  addData() {
    if (this.state.editIndex !== null) {
      const updateArr = [...this.state.arr];
      updateArr[this.state.editIndex] = this.state.txtvalue;
      this.setState({ arr: updateArr, txtvalue: "", editIndex: null });
    } else {
      if (this.state.txtvalue.trim()) {
        this.setState({
          arr: [...this.state.arr, this.state.txtvalue],
          txtvalue: "",
        });
      }
    }
  }

  handleEdit(index) {
    this.setState({ txtvalue: this.state.arr[index], editIndex: index });
  }

  handleDelete(index) {
    const updatedArr = this.state.arr.filter((_, i) => i !== index);
    this.setState({ arr: updatedArr });
  }

  render() {
    return (
      <div className="container mt-5">
        <Link to='/' className="btn btn-secondary mb-3">Home</Link>
        {/* Card Layout */}
        <div className="card shadow-lg p-4">
          <h2 className="text-center text-primary">To-Do List</h2>

          {/* Input Section */}
          <div className="input-group mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Enter task..."
              value={this.state.txtvalue}
              onChange={(e) => this.setState({ txtvalue: e.target.value })}
            />
            <button
              className={`ms-2 btn ${this.state.editIndex !== null ? "btn-warning" : "btn-success"}`}
              onClick={this.addData.bind(this)}
            >
              {this.state.editIndex !== null ? "Update Task" : "Add Task"}
            </button>
          </div>

          {/* Task List */}
          <ul className="list-group">
            {this.state.arr.length > 0 ? (
              this.state.arr.map((value, index) => (
                <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
                  <span>{value}</span>
                  <div>
                    <button className="btn btn-info btn-sm me-2" onClick={() => this.handleEdit(index)}>
                      Edit
                    </button>
                    <button className="btn btn-danger btn-sm" onClick={() => this.handleDelete(index)}>
                      Delete
                    </button>
                  </div>
                </li>
              ))
            ) : (
              <li className="list-group-item text-center text-muted">No Tasks Available</li>
            )}
          </ul>
        </div>
      </div>
    );
  }
}

export default ToDoWithClass;
